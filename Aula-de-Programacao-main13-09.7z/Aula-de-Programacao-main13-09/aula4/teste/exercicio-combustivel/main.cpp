#include <iostream>
#include <stdio.h>
#include <stdlib.h>


int main()
{
    int tipo;
    float quantidade, pagar;

    printf("1- Acool / 2- Diesel / 3- Gasolina: \n");
    printf("Tipo do combustivel: \n");
    scanf("%d", &tipo);

    printf("Digite a quantidade em litros \n");
    scanf("%f", &quantidade);


    switch(tipo){
    case 1:
        pagar = quantidade * 1.77997;
        break;

        case 2:
        pagar = quantidade * 0.9798;
        break;

        case 3:
        pagar = quantidade * 2.1009;
        break;
        default:
            printf("Entrada incorreta do tipo de combustivel");
        }
            printf("Total a pagar: %f \n",pagar);
            return 0;

}
