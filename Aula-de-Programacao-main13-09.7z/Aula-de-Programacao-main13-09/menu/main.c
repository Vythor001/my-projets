#include<stdio.h>
#include<stdlib.h>
#include <locale.h>





int main()
{
    setlocale(LC_ALL,"Portuguese");
    int continuar=1;




   do
    {

       printf("\n\tMenu de Cursos\n\n");
        printf("Informe uma op��o v�lida e aperte a tecla enter\n\n");
        printf("0. Sair\n");
        printf("1. Gest�o de TI\n");
        printf("2. An�lise d Desenvolvimento de Sistemas\n");
        printf("3. Seguran�a da Informa��o\n");
        printf("4. Media Aluno\n");
        printf("5. Diferen�a maior e menor \n");

       scanf("%d", &continuar);
        system("cls || clear");

      switch(continuar)
        {
             // case 0:
                //sair();
               // break;

            case 1:
                gestaoTI();
                break;

          case 2:
                analiseDesenvolvimentoSistemas();
                break;

          case 3:
                segurancaInformacao();
                break;

          case 4:
                mediaAluno();
                break;

          case 5:
                maiorMenor();
                break;

          default:
                printf("Digite uma opcao valida\n");
        }
    } while(continuar);
}
void gestaoTI()
{
   int main()
{
    int tipo;
    float quantidade, pagar;

    printf("1- Acool / 2- Diesel / 3- Gasolina: \n");
    printf("Tipo do combustivel: \n");
    scanf("%d", &tipo);

    printf("Digite a quantidade em litros \n");
    scanf("%f", &quantidade);


    switch(tipo){
    case 1:
        pagar = quantidade * 1.77997;
        break;

        case 2:
        pagar = quantidade * 0.9798;
        break;

        case 3:
        pagar = quantidade * 2.1009;
        break;
        default:
            printf("Entrada incorreta do tipo de combustivel");
        }
            printf("Total a pagar: %f \n",pagar);
}





void analiseDesenvolvimentoSistemas()
{
    system("cls || clear");
    printf("O analista e desenvolvedor de sistemas � o profissional respons�vel por desenvolver, projetar, analisar, implementar e realizar a manuten��o de sistemas de informa��o de diversos setores.\n");
}





void segurancaInformacao()
{
    system("cls || clear");
    printf("Seguran�a da informa��o � a pr�tica que mant�m os dados sens�veis em sigilo, a defesa do que n�o � p�blico\n");
}
void mediaAluno()
{
      system("cls || clear");
      printf("\tMedia do aluno, � a soma das 4 notas tiradas no ano, somadas e dividas por 4 para verificar se o aluno passou de ano, escolha suas notas e coloque.\n\n");



// declara��o de variaveis
      float nota1, nota2, nota3,nota4,mediaAnual,mediaFinal;

      // entrada
      printf("Digite a nota 1 : ");
    scanf("%f", &nota1);
      printf("Digite a nota 2 : ");
    scanf("%f", &nota2);
    printf("Digite a nota 3 : ");
    scanf("%f", &nota3);
    printf("Digite a nota 4 : ");
    scanf("%f", &nota4);





    // processamento
      mediaAnual = (nota1 + nota2 + nota3 + nota4) / 4 ;





  // criticar para saber se o aluno esta aprovado ou retido
    // saida
    if (mediaAnual >= 7)
      {
          printf("\n \tAPROVADO \n\n");
    }
      else
      {
        printf("\n \tREPROVADO \n\n");
      }



  // printf("Clique algum n�mero e precione enter para continuar: ");
    //scanf("%f");
    //system("cls || clear");


